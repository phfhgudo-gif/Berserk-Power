package dev.divinebreaker;

import java.util.ArrayList;
import java.util.List;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * /divinebreaker purify  (ต้อง permission level 2+)
 * ล้าง MobEffect ที่ category = HARMFUL ของ "entity ที่รันคำสั่ง" เท่านั้น (ไม่แตะ BENEFICIAL / NEUTRAL)
 * power Purification ของ Origins เรียกคำสั่งนี้ผ่าน apoli:execute_command (permission_level 4)
 * ครอบคลุมเอฟเฟกต์ของม็อดอื่นที่ประกาศตัวเองเป็น HARMFUL โดยอัตโนมัติ
 * ไม่ล้าง stun/knockdown ของ Epic Fight (ไม่ใช่ MobEffect)
 */
public final class PurifyCommand {
    private PurifyCommand() {
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("divinebreaker")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.literal("purify").executes(PurifyCommand::purify)));
    }

    private static int purify(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        Entity entity = context.getSource().getEntityOrException();
        if (!(entity instanceof LivingEntity living)) {
            return 0;
        }

        List<MobEffect> harmful = new ArrayList<>();
        for (MobEffectInstance instance : living.getActiveEffects()) {
            if (instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                harmful.add(instance.getEffect());
            }
        }

        int removed = 0;
        for (MobEffect effect : harmful) {
            if (living.removeEffect(effect)) {
                removed++;
            }
        }
        return removed;
    }
}
