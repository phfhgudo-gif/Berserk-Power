package dev.divinebreaker;

import java.util.ArrayList;
import java.util.List;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * /divinebreaker purify   ล้าง MobEffect ประเภท HARMFUL ของ entity ที่รันคำสั่ง (Purification เรียกผ่าน apoli:execute_command)
 * /divinebreaker effects  แสดง id + category ของเอฟเฟกต์ที่ติดตัวอยู่ (ใช้หา id จริงของเอฟเฟกต์ "Stop" ของ Epic Fight)
 * /divinebreaker pehkui   แสดงสถานะการเชื่อม Pehkui
 * ทั้งหมดต้อง permission level 2+
 */
public final class PurifyCommand {
    private PurifyCommand() {
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("divinebreaker")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.literal("purify").executes(PurifyCommand::purify))
                        .then(Commands.literal("effects").executes(PurifyCommand::effects))
                        .then(Commands.literal("pehkui").executes(PurifyCommand::pehkui)));
    }

    private static int purify(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        Entity entity = context.getSource().getEntityOrException();
        if (!(entity instanceof LivingEntity living)) {
            return 0;
        }

        List<MobEffect> harmful = new ArrayList<>();
        for (MobEffectInstance instance : living.getActiveEffects()) {
            if (instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                harmful.add(instance.getEffect());
            }
        }

        int removed = 0;
        for (MobEffect effect : harmful) {
            if (living.removeEffect(effect)) {
                removed++;
            }
        }
        return removed;
    }

    private static int effects(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        Entity entity = context.getSource().getEntityOrException();
        if (!(entity instanceof LivingEntity living)) {
            return 0;
        }
        int count = 0;
        for (MobEffectInstance instance : new ArrayList<>(living.getActiveEffects())) {
            ResourceLocation id = ForgeRegistries.MOB_EFFECTS.getKey(instance.getEffect());
            String line = id + " [" + instance.getEffect().getCategory() + "]";
            context.getSource().sendSuccess(() -> Component.literal(line), false);
            count++;
        }
        if (count == 0) {
            context.getSource().sendSuccess(() -> Component.literal("(ไม่มีเอฟเฟกต์ติดตัว)"), false);
        }
        return count;
    }

    private static int pehkui(CommandContext<CommandSourceStack> context) {
        PehkuiBridge.init();
        String line = "Pehkui bridge: " + PehkuiBridge.status();
        context.getSource().sendSuccess(() -> Component.literal(line), false);
        return 1;
    }
}
