package dev.divinebreaker;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Attribute "ตัวบ่งชี้" 3 ตัว (ค่า 0..1) ที่ power JSON ของ Origins (apoli:attribute) ใส่ให้ผู้เล่น
 * ฝั่ง Java อ่านค่านี้เพื่อรู้ว่าผู้เล่นมีสกิลหรือไม่ โดยไม่ต้องเรียก API ภายในของ Origins/Apoli
 * ค่า 1.0 = เปิดเต็ม (Armor Breaker: เจาะ 100%)
 */
public final class ModAttributes {
    public static final DeferredRegister<Attribute> ATTRIBUTES =
            DeferredRegister.create(ForgeRegistries.ATTRIBUTES, DivineBreaker.MOD_ID);

    public static final RegistryObject<Attribute> ARMOR_BREAKER = register("armor_breaker");
    public static final RegistryObject<Attribute> SOUL_WALKER = register("soul_walker");
    public static final RegistryObject<Attribute> WEB_PHANTOM = register("web_phantom");
    public static final RegistryObject<Attribute> STOP_CLEANSER = register("stop_cleanser");

    private static RegistryObject<Attribute> register(String name) {
        return ATTRIBUTES.register(name, () ->
                new RangedAttribute("attribute.name." + DivineBreaker.MOD_ID + "." + name, 0.0D, 0.0D, 1.0D)
                        .setSyncable(true)); // ต้อง sync ไป client เพราะ Soul Walker คำนวณฝั่ง client
    }

    public static void onAttributeModification(EntityAttributeModificationEvent event) {
        event.add(EntityType.PLAYER, ARMOR_BREAKER.get());
        event.add(EntityType.PLAYER, SOUL_WALKER.get());
        event.add(EntityType.PLAYER, WEB_PHANTOM.get());
        event.add(EntityType.PLAYER, STOP_CLEANSER.get());
    }

    private ModAttributes() {
    }
}
