package dev.divinebreaker;

import java.lang.reflect.Method;

import net.minecraft.world.entity.Entity;
import net.minecraftforge.fml.ModList;

/**
 * เชื่อม Pehkui ด้วย reflection (ไม่มี compile dependency) — อ่าน/เขียนค่า scale ของ pehkui:defense และ pehkui:attack
 * ชื่อคลาส/เมธอดที่ใช้ (virtuoel.pehkui.api.ScaleTypes.DEFENSE / ATTACK, ScaleType#getScaleData(Entity),
 * ScaleData#getScale(), ScaleData#setScale(float)) มาจากความรู้ของผม ยังไม่ได้ยืนยันกับซอร์ส Pehkui
 * ถ้าหาไม่เจอหรือเรียกแล้ว error: ปิดตัวเอง (ไม่แก้อะไร) และบันทึกเหตุผลไว้ใน status
 */
public final class PehkuiBridge {
    private static boolean tried;
    private static boolean ready;
    private static String status = "not started";
    private static Method getScaleData;
    private static Method getScale;
    private static Method setScale;

    /** scale type หนึ่งชนิดของ Pehkui */
    public static final class Scale {
        private final String fieldName;
        private Object type;

        private Scale(String fieldName) {
            this.fieldName = fieldName;
        }

        /** ค่า scale ปัจจุบันของ entity หรือ null ถ้าอ่านไม่ได้ */
        public Float read(Entity entity) {
            if (!ready || type == null) {
                return null;
            }
            try {
                Object data = getScaleData.invoke(type, entity);
                return ((Number) getScale.invoke(data)).floatValue();
            } catch (Throwable t) {
                disable(t);
                return null;
            }
        }

        public boolean write(Entity entity, float value) {
            if (!ready || type == null) {
                return false;
            }
            try {
                Object data = getScaleData.invoke(type, entity);
                setScale.invoke(data, value);
                return true;
            } catch (Throwable t) {
                disable(t);
                return false;
            }
        }
    }

    public static final Scale DEFENSE = new Scale("DEFENSE");
    public static final Scale ATTACK = new Scale("ATTACK");

    private PehkuiBridge() {
    }

    public static boolean installed() {
        return ModList.get().isLoaded("pehkui");
    }

    public static synchronized boolean init() {
        if (tried) {
            return ready;
        }
        tried = true;
        if (!installed()) {
            status = "Pehkui not installed";
            return false;
        }
        try {
            Class<?> typesClass = Class.forName("virtuoel.pehkui.api.ScaleTypes");
            DEFENSE.type = typesClass.getField(DEFENSE.fieldName).get(null);
            ATTACK.type = typesClass.getField(ATTACK.fieldName).get(null);
            Class<?> typeClass = Class.forName("virtuoel.pehkui.api.ScaleType");
            getScaleData = find(typeClass, "getScaleData", 1, null);
            Class<?> dataClass = getScaleData.getReturnType();
            getScale = find(dataClass, "getScale", 0, null);
            setScale = find(dataClass, "setScale", 1, float.class);
            ready = true;
            status = "ready";
            DivineBreaker.LOGGER.info("[divinebreaker] Pehkui bridge ready");
        } catch (Throwable t) {
            ready = false;
            status = "disabled (Pehkui API not as expected): " + t;
            DivineBreaker.LOGGER.warn("[divinebreaker] Pehkui bridge disabled: {}", t.toString());
        }
        return ready;
    }

    public static String status() {
        return status;
    }

    private static void disable(Throwable t) {
        ready = false;
        status = "disabled after error: " + t;
        DivineBreaker.LOGGER.warn("[divinebreaker] Pehkui bridge disabled after error: {}", t.toString());
    }

    private static Method find(Class<?> cls, String name, int params, Class<?> firstParam) throws NoSuchMethodException {
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == params
                    && (firstParam == null || m.getParameterTypes()[0] == firstParam)) {
                m.setAccessible(true);
                return m;
            }
        }
        throw new NoSuchMethodException(cls.getName() + "#" + name);
    }
}
