package dev.divinebreaker;

import java.lang.reflect.Method;

import net.minecraft.world.entity.Entity;
import net.minecraftforge.fml.ModList;

/**
 * เชื่อม Pehkui ด้วย reflection (ไม่มี compile dependency) — อ่าน/เขียนค่า scale ของ pehkui:defense
 * ชื่อคลาส/เมธอดที่ใช้ (virtuoel.pehkui.api.ScaleTypes.DEFENSE, ScaleType#getScaleData(Entity),
 * ScaleData#getScale(), ScaleData#setScale(float)) มาจากความรู้ของผม ยังไม่ได้ยืนยันกับซอร์ส Pehkui
 * ถ้าหาไม่เจอหรือเรียกแล้ว error: ปิดตัวเอง (ไม่แก้อะไร) และบันทึกเหตุผลไว้ใน status
 */
public final class PehkuiBridge {
    private static boolean tried;
    private static boolean ready;
    private static String status = "not started";
    private static Object defenseType;
    private static Method getScaleData;
    private static Method getScale;
    private static Method setScale;

    private PehkuiBridge() {
    }

    public static synchronized boolean init() {
        if (tried) {
            return ready;
        }
        tried = true;
        if (!ModList.get().isLoaded("pehkui")) {
            status = "Pehkui not installed";
            return false;
        }
        try {
            Class<?> typesClass = Class.forName("virtuoel.pehkui.api.ScaleTypes");
            defenseType = typesClass.getField("DEFENSE").get(null);
            Class<?> typeClass = Class.forName("virtuoel.pehkui.api.ScaleType");
            getScaleData = find(typeClass, "getScaleData", 1, null);
            Class<?> dataClass = getScaleData.getReturnType();
            getScale = find(dataClass, "getScale", 0, null);
            setScale = find(dataClass, "setScale", 1, float.class);
            ready = true;
            status = "ready";
            DivineBreaker.LOGGER.info("[divinebreaker] Pehkui bridge ready");
        } catch (Throwable t) {
            ready = false;
            status = "disabled (Pehkui API not as expected): " + t;
            DivineBreaker.LOGGER.warn("[divinebreaker] Pehkui bridge disabled: {}", t.toString());
        }
        return ready;
    }

    public static boolean installed() {
        return ModList.get().isLoaded("pehkui");
    }

    public static String status() {
        return status;
    }

    /** ค่า pehkui:defense ปัจจุบันของ entity หรือ null ถ้าอ่านไม่ได้ */
    public static Float read(Entity entity) {
        if (!ready) {
            return null;
        }
        try {
            Object data = getScaleData.invoke(defenseType, entity);
            return ((Number) getScale.invoke(data)).floatValue();
        } catch (Throwable t) {
            disable(t);
            return null;
        }
    }

    public static boolean write(Entity entity, float value) {
        if (!ready) {
            return false;
        }
        try {
            Object data = getScaleData.invoke(defenseType, entity);
            setScale.invoke(data, value);
            return true;
        } catch (Throwable t) {
            disable(t);
            return false;
        }
    }

    private static void disable(Throwable t) {
        ready = false;
        status = "disabled after error: " + t;
        DivineBreaker.LOGGER.warn("[divinebreaker] Pehkui bridge disabled after error: {}", t.toString());
    }

    private static Method find(Class<?> cls, String name, int params, Class<?> firstParam) throws NoSuchMethodException {
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == params
                    && (firstParam == null || m.getParameterTypes()[0] == firstParam)) {
                m.setAccessible(true);
                return m;
            }
        }
        throw new NoSuchMethodException(cls.getName() + "#" + name);
    }
}
