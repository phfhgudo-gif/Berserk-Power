package dev.divinebreaker;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Purification (ฝั่ง Java): power JSON สั่ง "/tag @s add divinebreaker_purify" (คำสั่งของ vanilla ผ่าน apoli:execute_command)
 * ท้าย tick ถัดไป handler นี้เห็นแท็ก -> ลบแท็ก -> ล้าง MobEffect ที่ category = HARMFUL ของผู้เล่นคนนั้น
 * (ไม่แตะ BENEFICIAL / NEUTRAL) ม็อดนี้ไม่มีคำสั่งของตัวเองให้พิมพ์
 */
public final class PurifyHandler {
    public static final String REQUEST_TAG = "divinebreaker_purify";

    private PurifyHandler() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide() || !player.getTags().contains(REQUEST_TAG)) {
            return;
        }
        player.removeTag(REQUEST_TAG);

        List<MobEffect> harmful = new ArrayList<>();
        for (MobEffectInstance instance : player.getActiveEffects()) {
            if (instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                harmful.add(instance.getEffect());
            }
        }
        for (MobEffect effect : harmful) {
            player.removeEffect(effect);
        }
    }
}
