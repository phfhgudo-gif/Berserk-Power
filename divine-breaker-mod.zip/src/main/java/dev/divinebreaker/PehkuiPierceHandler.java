package dev.divinebreaker;

import java.util.IdentityHashMap;
import java.util.Map;

import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Armor Breaker -> เจาะ pehkui:defense ของเป้าหมายด้วย
 *
 * วิธี: ก่อนการโจมตี (AttackEntityEvent = ตีธรรมดา, LivingAttackEvent = ทุกเส้นทางรวม Epic Fight) ตั้งค่า pehkui:defense
 * ของเป้าหมายเป็นค่ากลาง (1.0 ที่ pierce=100%) ผ่าน PehkuiBridge แล้วคืนค่าเดิมใน LivingDamageEvent
 * (มีตัวสำรองคืนค่าตอนจบ server tick) — ไม่ต้องรู้สูตรภายในของ Pehkui
 *
 * ข้อจำกัดที่ยังไม่ได้ยืนยัน: ถ้า Pehkui ลดดาเมจ "ก่อน" LivingAttackEvent (เช่น ต้นเมธอด hurt) ทางที่ไม่ใช่ AttackEntityEvent
 * (เช่น Epic Fight) จะเข้าไปแก้ไม่ทัน -> ต้องทดสอบจริง (README ข้อ 7 ตารางข้อ 6)
 */
public final class PehkuiPierceHandler {
    private static final Map<Entity, Float> SAVED = new IdentityHashMap<>();

    private PehkuiPierceHandler() {
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttackEntity(AttackEntityEvent event) {
        neutralize(event.getEntity(), event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingAttack(LivingAttackEvent event) {
        DamageSource source = event.getSource();
        if (source.is(DamageTypes.THORNS)) {
            return;
        }
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if (direct != null && direct != attacker) {
            return;
        }
        neutralize(attacker, event.getEntity());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onDamage(LivingDamageEvent event) {
        restore(event.getEntity());
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || SAVED.isEmpty()) {
            return;
        }
        for (Entity entity : SAVED.keySet().toArray(new Entity[0])) {
            restore(entity);
        }
    }

    private static void neutralize(Entity attacker, Entity target) {
        if (!(attacker instanceof Player player) || target == null || player.level().isClientSide()) {
            return;
        }
        if (SAVED.containsKey(target) || !PehkuiBridge.init()) {
            return;
        }
        AttributeInstance breaker = player.getAttribute(ModAttributes.ARMOR_BREAKER.get());
        double pierce = breaker == null ? 0.0D : Mth.clamp(breaker.getValue(), 0.0D, 1.0D);
        if (pierce <= 0.0D) {
            return;
        }
        Float defense = PehkuiBridge.read(target);
        if (defense == null || Math.abs(defense - 1.0F) < 1.0E-4F) {
            return;
        }
        float neutral = (float) (defense + (1.0D - defense) * pierce);
        if (PehkuiBridge.write(target, neutral)) {
            SAVED.put(target, defense);
        }
    }

    private static void restore(Entity target) {
        Float original = SAVED.remove(target);
        if (original != null) {
            PehkuiBridge.write(target, original);
        }
    }
}
