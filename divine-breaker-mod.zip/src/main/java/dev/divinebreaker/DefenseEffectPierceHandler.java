package dev.divinebreaker;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Armor Breaker -> เจาะ "เอฟเฟกต์ป้องกัน" ของเป้าหมาย (Resistance, Absorption และเอฟเฟกต์ป้องกันของม็อดอื่น)
 *
 * วิธี: ใน LivingHurtEvent (HIGHEST = ก่อนเกมคำนวณ Resistance/Absorption และก่อนม็อดอื่นอ่านเอฟเฟกต์) เมื่อผู้โจมตีเป็นผู้เล่นที่มี
 * Armor Breaker เต็ม 100%:
 *   - "ซ่อน" เอฟเฟกต์ป้องกันของเป้าหมายชั่วคราว โดยดึงออกจาก map ของเอฟเฟกต์ที่ติดอยู่ (ไม่เรียก removeEffect จึงไม่มี event,
 *     ไม่มีแพ็กเก็ตไป client, ไม่เรียก onEffectRemoved)
 *   - ตั้ง absorption (หัวใจทอง) เป็น 0 ชั่วคราว
 * แล้วคืนทั้งหมดใน LivingDamageEvent (HIGHEST) — มีตัวสำรองคืนตอนจบ server tick  => ไม่ได้ลบเอฟเฟกต์/หัวใจทอง แค่ไม่ถูกนับในการโจมตีนั้น
 *
 * "เอฟเฟกต์ป้องกัน" ในที่นี้:
 *   1) minecraft:resistance (MobEffects.DAMAGE_RESISTANCE) และ minecraft:absorption
 *   2) เอฟเฟกต์ของม็อดอื่น (namespace ไม่ใช่ minecraft) ที่เป็น BENEFICIAL และ registry path มีคำเหล่านี้:
 *      resist, protect, defen, shield, armor, armour, barrier, absorb, guard, fortif, tough  (ใช้ชื่อเดา ไม่ใช่รายการยืนยันแล้ว)
 * ไม่รวม: Protection (enchant), การบล็อกด้วยโล่, i-frames — ไม่ใช่เอฟเฟกต์ยา
 */
public final class DefenseEffectPierceHandler {
    private static final String[] KEYWORDS = {
            "resist", "protect", "defen", "shield", "armor", "armour", "barrier", "absorb", "guard", "fortif", "tough"
    };

    private static final class Saved {
        final List<MobEffectInstance> hidden = new ArrayList<>();
        float absorption;
    }

    private static final Map<LivingEntity, Saved> HIDDEN = new IdentityHashMap<>();

    private DefenseEffectPierceHandler() {
    }

    static boolean isDefensive(MobEffect effect) {
        if (effect == MobEffects.DAMAGE_RESISTANCE || effect == MobEffects.ABSORPTION) {
            return true;
        }
        ResourceLocation id = ForgeRegistries.MOB_EFFECTS.getKey(effect);
        if (id == null || "minecraft".equals(id.getNamespace()) || effect.getCategory() != MobEffectCategory.BENEFICIAL) {
            return false;
        }
        String path = id.getPath();
        for (String keyword : KEYWORDS) {
            if (path.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide() || HIDDEN.containsKey(target)) {
            return;
        }
        DamageSource source = event.getSource();
        if (source.is(DamageTypes.THORNS)) {
            return;
        }
        Entity attacker = source.getEntity();
        if (!(attacker instanceof Player player)) {
            return;
        }
        Entity direct = source.getDirectEntity();
        if (direct != null && direct != attacker) {
            return;
        }
        AttributeInstance breaker = player.getAttribute(ModAttributes.ARMOR_BREAKER.get());
        if (breaker == null || breaker.getValue() < 0.999D) {
            return; // เอฟเฟกต์ป้องกันซ่อนได้แบบเปิด/ปิดเท่านั้น -> ทำเมื่อเจาะเต็ม 100%
        }
        hide(target);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onDamage(LivingDamageEvent event) {
        restore(event.getEntity());
    }

    /** ตัวสำรอง: ถ้าไม่มี LivingDamageEvent (ม็อดอื่น cancel / ดาเมจเหลือ 0) ให้คืนตอนจบ tick */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || HIDDEN.isEmpty()) {
            return;
        }
        for (LivingEntity entity : HIDDEN.keySet().toArray(new LivingEntity[0])) {
            restore(entity);
        }
    }

    private static void hide(LivingEntity target) {
        Saved saved = new Saved();
        Map<MobEffect, MobEffectInstance> active = target.getActiveEffectsMap();
        for (MobEffect effect : new ArrayList<>(active.keySet())) {
            if (isDefensive(effect)) {
                MobEffectInstance instance = active.remove(effect);
                if (instance != null) {
                    saved.hidden.add(instance);
                }
            }
        }
        saved.absorption = target.getAbsorptionAmount();
        if (saved.absorption > 0.0F) {
            target.setAbsorptionAmount(0.0F);
        }
        if (!saved.hidden.isEmpty() || saved.absorption > 0.0F) {
            HIDDEN.put(target, saved);
        }
    }

    private static void restore(LivingEntity target) {
        Saved saved = HIDDEN.remove(target);
        if (saved == null) {
            return;
        }
        Map<MobEffect, MobEffectInstance> active = target.getActiveEffectsMap();
        for (MobEffectInstance instance : saved.hidden) {
            if (!active.containsKey(instance.getEffect())) {
                active.put(instance.getEffect(), instance);
            }
        }
        if (saved.absorption > 0.0F) {
            target.setAbsorptionAmount(target.getAbsorptionAmount() + saved.absorption);
        }
    }
}
