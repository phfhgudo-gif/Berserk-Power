package dev.divinebreaker;

import java.util.IdentityHashMap;
import java.util.Map;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Attack Dampener (passive ซ่อนในหน้าเลือกพลัง)
 *
 * เมื่อผู้โจมตีที่ "ปรับ" pehkui:attack scale ไว้ (ค่า != 1) โจมตีผู้เล่นที่มี Origin นี้:
 *   - เก็บค่า scale เดิม (เช่น 10) แล้วลดเหลือครึ่งหนึ่งของค่าเดิม (10 -> 5)
 *   - คงค่าที่ลดไว้ "ตราบใดที่เขายังตีเราอยู่" (ทุกครั้งที่ตี/พยายามตี จะต่อเวลา)
 *   - เมื่อเขาไม่ตีเรานาน GRACE_TICKS (60 ticks = 3 วินาที) -> คืนเป็นค่าเดิม (10)
 * ผู้โจมตีที่ไม่ได้ปรับ scale (ค่า 1.0) ไม่ถูกแตะ; ถ้ามีคนสั่งเปลี่ยน scale ระหว่างที่ถูกลด จะยึดค่าใหม่เป็น "ค่าเดิม" / ไม่เขียนทับค่าที่ถูกเปลี่ยน
 *
 * ครอบคลุมดาเมจที่มีผู้โจมตีทุกแบบ (ตีธรรมดา, ธนู/กระสุน, /damage ... by <entity>)
 * ผลข้างเคียงที่หลีกเลี่ยงไม่ได้: ระหว่างช่วงนี้ ดาเมจที่เขาทำกับคนอื่นก็ลดด้วย (scale Attack เป็นของตัวเขา)
 *
 * กันค่าค้าง: คืนค่าเมื่อผู้โจมตีออกจากเกม/ถูกลบ/ตาย (EntityLeaveLevelEvent), ผู้เล่นล็อกเอาต์ และตอนเซิร์ฟเวอร์กำลังปิด
 * ข้อจำกัดที่ยังไม่ได้ยืนยัน: ถ้า Pehkui คูณ scale Attack ก่อนจุดที่เราเข้าไปแก้ ครั้งแรกที่ตีอาจยังไม่ลด (ครั้งถัดไปลดแล้วเพราะ scale ถูกตั้งไว้ก่อน)
 */
public final class AttackScaleDampenHandler {
    private static final float FACTOR = 0.5F;
    private static final float EPS = 1.0E-3F;
    private static final long GRACE_TICKS = 60L;

    private static final class State {
        final float original;
        final float applied;
        long lastHit;

        State(float original, float applied, long lastHit) {
            this.original = original;
            this.applied = applied;
            this.lastHit = lastHit;
        }
    }

    /** ผู้โจมตีที่กำลังถูกลด scale Attack -> ค่าเดิม + เวลาที่ตีเราครั้งล่าสุด */
    private static final Map<Entity, State> ACTIVE = new IdentityHashMap<>();

    private AttackScaleDampenHandler() {
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttackEntity(AttackEntityEvent event) {
        touch(event.getEntity(), event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingAttack(LivingAttackEvent event) {
        touch(event.getSource().getEntity(), event.getEntity());
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ACTIVE.isEmpty()) {
            return;
        }
        for (Entity attacker : ACTIVE.keySet().toArray(new Entity[0])) {
            State state = ACTIVE.get(attacker);
            if (state == null) {
                continue;
            }
            if (attacker.isRemoved() || attacker.level().getGameTime() - state.lastHit >= GRACE_TICKS) {
                restore(attacker);
            }
        }
    }

    @SubscribeEvent
    public static void onEntityLeave(EntityLeaveLevelEvent event) {
        if (!ACTIVE.isEmpty() && !event.getLevel().isClientSide()) {
            restore(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!ACTIVE.isEmpty()) {
            restore(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        for (Entity attacker : ACTIVE.keySet().toArray(new Entity[0])) {
            restore(attacker);
        }
    }

    private static void touch(Entity attacker, Entity target) {
        if (attacker == null || target == null || attacker == target || attacker.level().isClientSide()) {
            return;
        }
        if (!(target instanceof Player player)) {
            return;
        }
        AttributeInstance marker = player.getAttribute(ModAttributes.ATTACK_DAMPENER.get());
        if (marker == null || marker.getValue() <= 0.0D || !PehkuiBridge.init()) {
            return;
        }
        Float scale = PehkuiBridge.ATTACK.read(attacker);
        if (scale == null) {
            return;
        }
        long now = attacker.level().getGameTime();
        State state = ACTIVE.get(attacker);
        if (state != null) {
            state.lastHit = now; // ยังตีอยู่ -> ต่อเวลา
            if (Math.abs(scale - state.applied) > EPS) {
                // มีคนเปลี่ยน scale ระหว่างที่ถูกลด -> ถือเป็นค่าเดิมใหม่ (ถ้ายังเป็นค่าที่ปรับไว้) แล้วลดครึ่งหนึ่งอีกครั้ง
                ACTIVE.remove(attacker);
                reduce(attacker, scale, now);
            }
            return;
        }
        reduce(attacker, scale, now);
    }

    private static void reduce(Entity attacker, float scale, long now) {
        if (scale <= EPS || Math.abs(scale - 1.0F) <= EPS) {
            return; // ไม่ได้ปรับ scale (1.0) หรือเป็น 0 -> ไม่แตะ
        }
        float reduced = scale * FACTOR;
        if (PehkuiBridge.ATTACK.write(attacker, reduced)) {
            ACTIVE.put(attacker, new State(scale, reduced, now));
        }
    }

    private static void restore(Entity attacker) {
        State state = ACTIVE.remove(attacker);
        if (state == null) {
            return;
        }
        Float current = PehkuiBridge.ATTACK.read(attacker);
        // ถ้าตอนนี้ไม่ใช่ค่าที่เราตั้งไว้แล้ว แปลว่ามีคนเปลี่ยนค่า -> ไม่เขียนทับ
        if (current == null || Math.abs(current - state.applied) < EPS) {
            PehkuiBridge.ATTACK.write(attacker, state.original);
        }
    }
}
