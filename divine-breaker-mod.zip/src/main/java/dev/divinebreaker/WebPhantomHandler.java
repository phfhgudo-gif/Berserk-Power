package dev.divinebreaker;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Web Phantom: ไม่ถูกใยแมงมุมชะลอ
 *
 * กลไกของเกม: WebBlock#entityInside เรียก Entity#makeStuckInBlock(state, (0.25, 0.05, 0.25)) -> ค่า stuckSpeedMultiplier
 * จะถูกใช้ตอน Entity#move ครั้งถัดไป (คูณการเคลื่อนที่ + ล้าง deltaMovement)
 * เราเรียก makeStuckInBlock(cobweb, Vec3.ZERO) (เมธอด public) หลังจบ tick ของผู้เล่นที่มี attribute -> ตัวคูณถูกเขียนทับเป็น 0
 * (ในเกม ตัวคูณ <= 1e-7 ถือว่าไม่มี) และยังคง resetFallDistance แบบเดียวกับใยแมงมุมปกติ
 *
 * ไม่แก้ block ใยแมงมุม ไม่กระทบ entity อื่น ทำงานทั้ง client และ server (ผู้เล่นที่มี attribute เท่านั้น)
 * ถ้าตัวผู้เล่นทับ sweet berry bush / powder snow อยู่ด้วย จะไม่แตะอะไร (ไม่ลบการชะลอของบล็อกอื่น)
 */
public final class WebPhantomHandler {
    private WebPhantomHandler() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        AttributeInstance marker = player.getAttribute(ModAttributes.WEB_PHANTOM.get());
        if (marker == null || marker.getValue() <= 0.0D) {
            return;
        }

        AABB box = player.getBoundingBox().deflate(1.0E-3D);
        BlockPos min = BlockPos.containing(box.minX, box.minY, box.minZ);
        BlockPos max = BlockPos.containing(box.maxX, box.maxY, box.maxZ);

        boolean inWeb = false;
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            BlockState state = player.level().getBlockState(pos);
            if (state.is(Blocks.COBWEB)) {
                inWeb = true;
            } else if (state.is(Blocks.SWEET_BERRY_BUSH) || state.is(Blocks.POWDER_SNOW)) {
                return;
            }
        }
        if (inWeb) {
            player.makeStuckInBlock(Blocks.COBWEB.defaultBlockState(), Vec3.ZERO);
        }
    }
}
