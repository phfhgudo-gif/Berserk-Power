package dev.divinebreaker;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(DivineBreaker.MOD_ID)
public class DivineBreaker {
    public static final String MOD_ID = "divinebreaker";
    public static final Logger LOGGER = LogUtils.getLogger();

    public DivineBreaker() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModAttributes.ATTRIBUTES.register(modBus);
        modBus.addListener(ModAttributes::onAttributeModification);

        // handler ที่เป็น static method ทั้งหมด -> register ด้วย Class
        MinecraftForge.EVENT_BUS.register(ArmorBreakerHandler.class);
        MinecraftForge.EVENT_BUS.register(WebPhantomHandler.class);
        MinecraftForge.EVENT_BUS.register(PurifyHandler.class);
        MinecraftForge.EVENT_BUS.register(StopCleanserHandler.class);
        MinecraftForge.EVENT_BUS.register(PehkuiPierceHandler.class);
        // dev.divinebreaker.client.SoulWalkerClient ลงทะเบียนตัวเองผ่าน @Mod.EventBusSubscriber (เฉพาะฝั่ง client)
    }
}
