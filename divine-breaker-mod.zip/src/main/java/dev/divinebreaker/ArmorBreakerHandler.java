package dev.divinebreaker;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.UUID;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Armor Breaker: เจาะ Armor และ Armor Toughness ของเป้าหมาย (ตามค่า attribute divinebreaker:armor_breaker, 1.0 = 100%)
 *
 * วิธีทำ: ใน LivingHurtEvent (ก่อนที่ Minecraft จะคำนวณเกราะ) ใส่ modifier ชั่วคราวแบบ MULTIPLY_TOTAL (-pierce)
 * ให้ attribute ARMOR และ ARMOR_TOUGHNESS ของเป้าหมาย -> สูตรเกราะของเกม (และของ Epic Fight ที่อ่านค่า attribute เดียวกัน)
 * จะเห็นเกราะ = 0 แล้วถอด modifier ออกใน LivingDamageEvent (เกิดหลังคำนวณเกราะ) + มีตัวสำรองถอดตอนจบ server tick
 *
 * - ไม่แก้ amount ของดาเมจ ไม่เรียก hurt() ซ้ำ -> ไม่มีดาเมจซ้ำ
 * - Resistance / Absorption / invulnerability frames / shield / Protection enchant ยังทำงานตามปกติ (ไม่ได้ถูกเจาะ)
 * - นับเฉพาะการโจมตีที่ผู้เล่นเป็นผู้โจมตีโดยตรง (ระยะประชิด/อาวุธ รวม Epic Fight) ไม่รวมกระสุน/ระเบิด/thorns
 */
public final class ArmorBreakerHandler {
    private static final UUID PIERCE_ID = UUID.fromString("7d3c0e0e-4a76-4c1b-9a1e-5f2b8d6c1a90");
    private static final String PIERCE_NAME = "divinebreaker:armor_breaker_pierce";
    private static final Set<LivingEntity> PENDING = Collections.newSetFromMap(new IdentityHashMap<>());

    private ArmorBreakerHandler() {
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide()) {
            return;
        }

        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_ARMOR) || source.is(DamageTypes.THORNS)) {
            return;
        }

        Entity attacker = source.getEntity();
        if (!(attacker instanceof Player player)) {
            return;
        }
        Entity direct = source.getDirectEntity();
        if (direct != null && direct != attacker) {
            return; // กระสุน/ระเบิด ฯลฯ ไม่นับ
        }

        AttributeInstance breaker = player.getAttribute(ModAttributes.ARMOR_BREAKER.get());
        if (breaker == null) {
            return;
        }
        double pierce = Mth.clamp(breaker.getValue(), 0.0D, 1.0D);
        if (pierce <= 0.0D) {
            return;
        }

        boolean changed = pierceAttribute(target, Attributes.ARMOR, pierce);
        changed |= pierceAttribute(target, Attributes.ARMOR_TOUGHNESS, pierce);
        if (changed) {
            PENDING.add(target);
        }
    }

    /** เกิดหลังคำนวณเกราะ/magic/absorption แล้ว -> ถอด modifier คืน */
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onDamage(LivingDamageEvent event) {
        release(event.getEntity());
    }

    /** ตัวสำรอง: ถ้ามีม็อดอื่น cancel/ตั้งดาเมจเป็น 0 หลังเรา ทำให้ LivingDamageEvent ไม่เกิด */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || PENDING.isEmpty()) {
            return;
        }
        for (LivingEntity entity : PENDING.toArray(new LivingEntity[0])) {
            release(entity);
        }
        PENDING.clear();
    }

    private static boolean pierceAttribute(LivingEntity target, Attribute attribute, double pierce) {
        AttributeInstance instance = target.getAttribute(attribute);
        if (instance == null || instance.getValue() <= 0.0D || instance.getModifier(PIERCE_ID) != null) {
            return false;
        }
        instance.addTransientModifier(new AttributeModifier(
                PIERCE_ID, PIERCE_NAME, -pierce, AttributeModifier.Operation.MULTIPLY_TOTAL));
        return true;
    }

    private static void release(LivingEntity entity) {
        if (!PENDING.remove(entity)) {
            return;
        }
        removeModifier(entity, Attributes.ARMOR);
        removeModifier(entity, Attributes.ARMOR_TOUGHNESS);
    }

    private static void removeModifier(LivingEntity entity, Attribute attribute) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(PIERCE_ID);
        }
    }
}
