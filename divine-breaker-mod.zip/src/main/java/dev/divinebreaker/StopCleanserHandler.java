package dev.divinebreaker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Stop Cleanser (passive): เคลียร์เอฟเฟกต์ "Stop" (ของม็อด Epic Fight Nightfall / Epic Fight) ให้อัตโนมัติ — ไม่ต้องพิมพ์คำสั่ง
 *
 * ตรงกับ MobEffect เมื่อ
 *   (ก) registry path มีคำว่า "stop" (namespace ไหนก็ได้)  หรือ
 *   (ข) namespace เป็นตระกูล Epic Fight / Nightfall (epicfight, efn หรือมีคำว่า epicfight / nightfall) และ category ไม่ใช่ BENEFICIAL
 * 2 ชั้น: (1) MobEffectEvent.Applicable -> DENY ไม่ให้เอฟเฟกต์ติดเลย (2) ท้าย tick ล้างตัวที่หลุดเข้ามา
 *
 * หา id จริงโดยไม่ต้องเปิดไฟล์ log: เมื่อมีเอฟเฟกต์ของม็อดอื่น (ไม่ใช่ minecraft:) ติดผู้เล่นที่มี Origin นี้
 * จะส่งข้อความเข้าแชตของผู้เล่นคนนั้น เช่น "[Divine Breaker] BLOCKED: efn:stop [HARMFUL]" (และเขียนลง log ด้วย)
 * ตั้ง CHAT_FEEDBACK = false เมื่อไม่ต้องการข้อความนี้แล้ว
 * ข้อจำกัด: ถ้า Stop ไม่ใช่ MobEffect (เป็นสถานะภายในของม็อด) จะไม่ถูกล้าง และจะไม่มีข้อความขึ้น
 */
public final class StopCleanserHandler {
    private static final String EPIC_FIGHT = "epicfight";
    private static final boolean CHAT_FEEDBACK = true;
    private static final long REPORT_COOLDOWN_TICKS = 60L;
    private static final Map<String, Long> LAST_REPORT = new HashMap<>();

    private StopCleanserHandler() {
    }

    public static boolean matches(MobEffect effect) {
        ResourceLocation id = ForgeRegistries.MOB_EFFECTS.getKey(effect);
        if (id == null) {
            return false;
        }
        String namespace = id.getNamespace();
        if (id.getPath().contains("stop")) {
            return true;
        }
        boolean epicFightFamily = namespace.equals(EPIC_FIGHT) || namespace.equals("efn")
                || namespace.contains("epicfight") || namespace.contains("nightfall");
        return epicFightFamily && effect.getCategory() != MobEffectCategory.BENEFICIAL;
    }

    private static boolean active(Player player) {
        AttributeInstance marker = player.getAttribute(ModAttributes.STOP_CLEANSER.get());
        return marker != null && marker.getValue() > 0.0D;
    }

    /** แจ้ง id ของเอฟเฟกต์ (เฉพาะของม็อดอื่น) ทางแชต + log กันสแปมด้วย cooldown ต่อ (ผู้เล่น, เอฟเฟกต์, การกระทำ) */
    private static void report(Player player, MobEffect effect, String action) {
        ResourceLocation id = ForgeRegistries.MOB_EFFECTS.getKey(effect);
        if (id == null || "minecraft".equals(id.getNamespace())) {
            return;
        }
        long now = player.level().getGameTime();
        String key = player.getUUID() + "|" + id + "|" + action;
        Long last = LAST_REPORT.get(key);
        if (last != null && now - last < REPORT_COOLDOWN_TICKS) {
            return;
        }
        LAST_REPORT.put(key, now);

        String text = action + ": " + id + " [" + effect.getCategory() + "]";
        DivineBreaker.LOGGER.info("[divinebreaker] {} ({})", text, player.getName().getString());
        if (CHAT_FEEDBACK) {
            player.sendSystemMessage(Component.literal("[Divine Breaker] " + text));
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onApplicable(MobEffectEvent.Applicable event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide() || !active(player)) {
            return;
        }
        MobEffect effect = event.getEffectInstance().getEffect();
        if (matches(effect)) {
            try {
                event.setResult(Event.Result.DENY);
            } catch (RuntimeException ex) {
                // ถ้า event นี้ไม่รองรับ result ให้พึ่งการล้างท้าย tick
            }
            report(player, effect, "BLOCKED");
        } else {
            report(player, effect, "NOT MATCHED (applied)");
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide() || player.getActiveEffects().isEmpty() || !active(player)) {
            return;
        }
        for (MobEffectInstance instance : new ArrayList<>(player.getActiveEffects())) {
            MobEffect effect = instance.getEffect();
            if (matches(effect)) {
                player.removeEffect(effect);
                report(player, effect, "REMOVED");
            } else {
                report(player, effect, "NOT MATCHED (active)");
            }
        }
    }
}
