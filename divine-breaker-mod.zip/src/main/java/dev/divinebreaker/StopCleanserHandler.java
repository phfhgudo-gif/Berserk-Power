package dev.divinebreaker;

import java.util.ArrayList;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Stop Cleanser (passive): เคลียร์เอฟเฟกต์ "Stop" ของ Epic Fight ให้อัตโนมัติ
 *
 * ตรงกับ MobEffect ที่ registry id อยู่ใน namespace "epicfight" และ
 *   - path มีคำว่า "stop"  หรือ
 *   - category ไม่ใช่ BENEFICIAL  (กันเอฟเฟกต์ด้านลบอื่นของ Epic Fight ไปด้วย; ของดี เช่น stun immunity ไม่ถูกแตะ)
 * 2 ชั้น: (1) MobEffectEvent.Applicable -> DENY ไม่ให้เอฟเฟกต์ติดเลย (2) ท้าย tick ล้างตัวที่หลุดเข้ามา
 *
 * ข้อจำกัด: ผมยังไม่ได้ยืนยัน id จริงของเอฟเฟกต์ "Stop" ใน Epic Fight 20.14.17
 * ใช้ /divinebreaker effects (OP) ตอนติด Stop เพื่อดู id จริง และถ้าไม่ใช่ MobEffect (เป็นสถานะภายในของ Epic Fight) จะไม่ถูกล้าง
 */
public final class StopCleanserHandler {
    private static final String EPIC_FIGHT = "epicfight";

    private StopCleanserHandler() {
    }

    public static boolean matches(MobEffect effect) {
        ResourceLocation id = ForgeRegistries.MOB_EFFECTS.getKey(effect);
        if (id == null || !EPIC_FIGHT.equals(id.getNamespace())) {
            return false;
        }
        return id.getPath().contains("stop") || effect.getCategory() != MobEffectCategory.BENEFICIAL;
    }

    private static boolean active(Player player) {
        AttributeInstance marker = player.getAttribute(ModAttributes.STOP_CLEANSER.get());
        return marker != null && marker.getValue() > 0.0D;
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onApplicable(MobEffectEvent.Applicable event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide() || !active(player)) {
            return;
        }
        if (matches(event.getEffectInstance().getEffect())) {
            event.setResult(Event.Result.DENY);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide() || player.getActiveEffects().isEmpty() || !active(player)) {
            return;
        }
        for (MobEffectInstance instance : new ArrayList<>(player.getActiveEffects())) {
            if (matches(instance.getEffect())) {
                player.removeEffect(instance.getEffect());
            }
        }
    }
}
