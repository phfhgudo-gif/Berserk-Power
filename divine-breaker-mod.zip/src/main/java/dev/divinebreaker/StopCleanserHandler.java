package dev.divinebreaker;

import java.util.ArrayList;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Stop Cleanser (passive): เคลียร์เอฟเฟกต์ "Stop" (ของม็อด Epic Fight Nightfall / Epic Fight) ให้อัตโนมัติ — ไม่ต้องพิมพ์คำสั่ง
 *
 * ตรงกับ MobEffect เมื่อ
 *   (ก) registry path มีคำว่า "stop" (namespace ไหนก็ได้)  หรือ
 *   (ข) namespace เป็นตระกูล Epic Fight / Nightfall (epicfight, efn หรือมีคำว่า epicfight / nightfall) และ category ไม่ใช่ BENEFICIAL
 * 2 ชั้น: (1) MobEffectEvent.Applicable -> DENY ไม่ให้เอฟเฟกต์ติดเลย (2) ท้าย tick ล้างตัวที่หลุดเข้ามา
 *
 * ไม่มีข้อความขึ้นแชต (เวอร์ชันทดสอบที่ส่งข้อความ id ถูกถอดออกแล้ว) — บันทึกระดับ debug ลง log เท่านั้น
 * ข้อจำกัด: ถ้าเป็นสถานะภายในของม็อดที่ไม่ใช่ MobEffect จะไม่ถูกล้าง
 */
public final class StopCleanserHandler {
    private static final String EPIC_FIGHT = "epicfight";

    private StopCleanserHandler() {
    }

    public static boolean matches(MobEffect effect) {
        ResourceLocation id = ForgeRegistries.MOB_EFFECTS.getKey(effect);
        if (id == null) {
            return false;
        }
        String namespace = id.getNamespace();
        if (id.getPath().contains("stop")) {
            return true;
        }
        boolean epicFightFamily = namespace.equals(EPIC_FIGHT) || namespace.equals("efn")
                || namespace.contains("epicfight") || namespace.contains("nightfall");
        return epicFightFamily && effect.getCategory() != MobEffectCategory.BENEFICIAL;
    }

    private static boolean active(Player player) {
        AttributeInstance marker = player.getAttribute(ModAttributes.STOP_CLEANSER.get());
        return marker != null && marker.getValue() > 0.0D;
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onApplicable(MobEffectEvent.Applicable event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide() || !active(player)) {
            return;
        }
        MobEffect effect = event.getEffectInstance().getEffect();
        if (matches(effect)) {
            try {
                event.setResult(Event.Result.DENY);
            } catch (RuntimeException ex) {
                // ถ้า event นี้ไม่รองรับ result ให้พึ่งการล้างท้าย tick
            }
            DivineBreaker.LOGGER.debug("[divinebreaker] Stop Cleanser blocked {}", ForgeRegistries.MOB_EFFECTS.getKey(effect));
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide() || player.getActiveEffects().isEmpty() || !active(player)) {
            return;
        }
        for (MobEffectInstance instance : new ArrayList<>(player.getActiveEffects())) {
            MobEffect effect = instance.getEffect();
            if (matches(effect)) {
                player.removeEffect(effect);
                DivineBreaker.LOGGER.debug("[divinebreaker] Stop Cleanser removed {}", ForgeRegistries.MOB_EFFECTS.getKey(effect));
            }
        }
    }
}
