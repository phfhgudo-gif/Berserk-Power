package dev.divinebreaker.client;

import dev.divinebreaker.DivineBreaker;
import dev.divinebreaker.ModAttributes;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Soul Walker (ฝั่ง client เท่านั้น): ไม่ถูก Soul Sand ชะลอ
 *
 * กลไกของเกม: ท้าย Entity#move เกมคูณ deltaMovement แนวนอนด้วย Block#getSpeedFactor() (soul sand = 0.4)
 * ผู้เล่นขยับด้วยการจำลองฝั่ง client (server รับตำแหน่งจาก client) จึงแก้ที่ client
 * เมื่อจบ tick ของ "ผู้เล่นตัวเอง" ที่มี attribute และยืนบน/อยู่ในบล็อกที่อยู่ใน tag minecraft:soul_speed_blocks
 * เราหารความเร็วแนวนอนด้วย speedFactor นั้น (= ยกเลิกการคูณของเกมพอดี) ไม่เพิ่มความเร็วอย่างอื่น
 *
 * ข้อยกเว้น: ถ้าผู้เล่นมี Soul Speed enchant เกมจัดการเอง จึงไม่ทำซ้ำ / ไม่แตะ honey block / ไม่แตะผู้เล่นอื่น
 * หมายเหตุ: Soul Soil ใน vanilla 1.20.1 ไม่มี slowdown (speedFactor = 1.0) จึงไม่มีอะไรต้องแก้
 */
@Mod.EventBusSubscriber(modid = DivineBreaker.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class SoulWalkerClient {
    private SoulWalkerClient() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || player != minecraft.player || player.isPassenger()) {
            return;
        }

        AttributeInstance marker = player.getAttribute(ModAttributes.SOUL_WALKER.get());
        if (marker == null || marker.getValue() <= 0.0D) {
            return;
        }
        if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SOUL_SPEED, player) > 0) {
            return;
        }

        float factor = soulBlockSpeedFactor(player);
        if (factor <= 0.0F || factor >= 1.0F) {
            return;
        }

        Vec3 motion = player.getDeltaMovement();
        player.setDeltaMovement(motion.x / factor, motion.y, motion.z / factor);
    }

    /** ทำซ้ำลำดับเลือกบล็อกของ Entity#getBlockSpeedFactor แต่คืนค่าเฉพาะเมื่อบล็อกนั้นอยู่ใน soul_speed_blocks */
    private static float soulBlockSpeedFactor(Player player) {
        Level level = player.level();
        BlockState cause = level.getBlockState(player.blockPosition());
        float factor = cause.getBlock().getSpeedFactor();

        if (!cause.is(Blocks.WATER) && !cause.is(Blocks.BUBBLE_COLUMN) && factor == 1.0F) {
            BlockPos below = BlockPos.containing(player.getX(), player.getY() - 0.500001D, player.getZ());
            cause = level.getBlockState(below);
            factor = cause.getBlock().getSpeedFactor();
        }
        return cause.is(BlockTags.SOUL_SPEED_BLOCKS) ? factor : 1.0F;
    }
}
