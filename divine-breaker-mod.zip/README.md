# Divine Breaker — Origins Add-on (Minecraft 1.20.1 / Forge) — เวอร์ชัน 1.2.1

> ⚠️ **สถานะจริง:** โปรเจกต์นี้ **ยังไม่เคย Build เป็น JAR และยังไม่เคยทดสอบในเกม**
> (สภาพแวดล้อมที่เขียนไม่มีเครือข่ายสำหรับโหลด Forge/Gradle และไม่มี Minecraft)
> ทุกข้อที่เขียนว่า "ทำงานได้" คือ **เจตนาของการออกแบบ** จนกว่าจะ Build และทดสอบตามหัวข้อ 7 สำเร็จ

## 1. ภาพรวม

Origin: `divinebreaker:divine_breaker` (ชื่อในเกม **Divine Breaker**) ถูกเพิ่มเข้า layer `origins:origin`

| # | สกิล | ชนิด | ปุ่ม | ทำงานอย่างไร |
|---|------|------|------|--------------|
| 1 | Green Vitality | Active | Primary Ability | `apoli:active_self` → `apoli:heal` 50 HP (25 หัวใจ) + อนุภาคสีเขียว (`/particle` ผ่าน `apoli:execute_command`) • cooldown 200 ticks (10 วินาที) |
| 2 | Purification | Active | Secondary Ability | `apoli:active_self` → `/tag @s add divinebreaker_purify` (คำสั่งของ vanilla) แล้ว Java ล้าง MobEffect ประเภท HARMFUL ของผู้เล่นภายใน 1 tick • cooldown 100 ticks (5 วินาที — **ผมตั้งเอง** เพราะโจทย์ไม่ได้กำหนด) |
| 3 | Soul Walker | Passive | – | power `apoli:attribute` ใส่ตัวบ่งชี้ + Java (ฝั่ง client) ชดเชยการชะลอของ Soul Sand |
| 4 | Web Phantom | Passive | – | ตัวบ่งชี้ + Java เขียนทับตัวคูณการชะลอของใยแมงมุม |
| 5 | Armor Breaker | Passive | – | ตัวบ่งชี้ + Java ทำให้ระบบคำนวณดาเมจมองเห็น Armor/Armor Toughness ของเป้าหมายเป็น 0 เฉพาะตอนถูกโจมตีโดยผู้เล่น (เจาะ 100%) **และ (v1.1.0) ตั้งค่า `pehkui:defense` ของเป้าหมายเป็นกลางชั่วคราวระหว่างโจมตี แล้วคืนค่าเดิม** |
| 6 | Stop Cleanser (v1.1.0) | Passive | – | ตัวบ่งชี้ + Java: เอฟเฟกต์ Stop (ของ Epic Fight Nightfall) ถูกกันไม่ให้ติด (`MobEffectEvent.Applicable` → DENY) และล้างซ้ำท้ายทุก tick ถ้าหลุดเข้ามา |

## 2. สถานะการตรวจสอบ (ตามหลักฐานจริง)

| หัวข้อ | สถานะ | หลักฐาน / ข้อจำกัด |
|--------|--------|---------------------|
| Epic Fight 20.14.17 มีสำหรับ MC 1.20.1 Forge | ✅ | พบในรายการเวอร์ชันของ Epic Fight บน Modrinth (ผ่านหน้าโฮสต์ที่ mirror ข้อมูล) |
| สูตรเจาะเกราะของ Epic Fight | ⚠️ ตรวจบางส่วน | อ่าน `MixinLivingEntity.java` ของ repo Antikythera-Studios/epicfight (commit `ba3c0888`) ซึ่งเป็นโฟลเดอร์ **neoforge/ = NeoForge 1.21.1 ไม่ใช่ 20.14.17** โค้ดนั้น inject ที่ต้น `getDamageAfterArmorAbsorb`: ถ้า source เป็น `EpicFightDamageSource` (และไม่ใช่ `bypasses_armor`) ส่วนของดาเมจตามเปอร์เซ็นต์ Armor Negation ข้ามเกราะ ส่วนที่เหลือผ่าน `CombatRules.getDamageAfterAbsorb` โดยอ่านเกราะจาก `getArmorValue()` และ attribute `ARMOR_TOUGHNESS` → ผมจึงออกแบบให้แก้ที่ค่า attribute ทั้งสองนี้ (ไม่ผูกกับสูตรภายในของ Epic Fight) **ยังไม่ได้เปิดโค้ดสาขา 1.20.1 ต้องทดสอบจริง (ข้อ 4 ในตารางทดสอบ)** |
| Pehkui | ⚠️ ตรวจบางส่วน | หน้าโปรเจกต์ (CurseForge/Modrinth) ระบุ scale type `pehkui:attack` (ปรับดาเมจที่ทำ), `pehkui:defense` (ปรับดาเมจที่ได้รับ), `pehkui:attack_speed`, `pehkui:entity_reach`, `pehkui:falling` ฯลฯ → Pehkui **มี** ตัวคูณ defense ของตัวเอง แยกจากค่า Armor **Armor Breaker ไม่เจาะตัวคูณนี้** (ตามขอบเขตข้อ 7.4) ไม่ได้อ่านซอร์สว่าตัวคูณถูกใช้ก่อน/หลังเกราะ และไม่พบ API เชื่อม Epic Fight ในเอกสารที่อ่าน |
| Origins Forge 1.20.1 | ⚠️ ตรวจบางส่วน | repo `EdwinMindcraft/origins-architectury` (สาขา `1.20.x/forge`) หน้า releases มีรุ่น 1.20.1 ถึง `1.10.0.9` (อาจมีใหม่กว่า) โฮสต์บน Ladysnake Maven README ของ repo ระบุว่า Apoli Forge เป็นการเขียนใหม่บางส่วน ฟีเจอร์ของ Fabric บางอย่างยังไม่มี → ต้องดู log ว่า power โหลดครบ |
| JSON ของ Apoli ที่ใช้ | ⚠️ ตรวจกับเอกสาร Fabric | `apoli:active_self` (entity_action, cooldown, hud_render, key), `apoli:heal` (amount) ตรงกับเอกสาร Apoli; `apoli:and`, `apoli:execute_command`, `apoli:attribute` ใช้ตามรูปแบบมาตรฐานของ Origins/Apoli แต่ **ยังไม่เคยโหลดจริงบนพอร์ต Forge** ไฟล์ JSON ทุกไฟล์ parse ได้ในระดับ JSON (ตรวจด้วย Python) |
| API Minecraft/Forge ในโค้ด Java | ⚠️ ตรวจบางส่วน | ยืนยันจาก mappings.dev: `CombatRules.getDamageAfterAbsorb(float,float,float)` ใน 1.20.1 ส่วนอื่น (ลำดับ `LivingHurtEvent` → คำนวณเกราะ → `LivingDamageEvent`, `Entity#makeStuckInBlock`, `Block#getSpeedFactor` ฯลฯ) มาจากความรู้ของผม ไม่ได้เปิดซอร์สที่ถอดรหัสแล้วเพื่อยืนยัน |
| ตรวจ Java ด้วย javac | ⚠️ ระดับ syntax | ไม่มี syntax error และการอ้างอิงระหว่างคลาสในโปรเจกต์ resolve ได้ แต่ symbol ของ Minecraft/Forge ไม่อยู่ใน classpath ของเครื่องที่เขียน → **ไม่ใช่การ compile จริง** |
| เอฟเฟกต์ "Stop" ของ Epic Fight Nightfall (v1.1.0–1.2.1) | ❌ ยังไม่ได้ยืนยัน | ผู้ใช้แจ้งว่า Stop เป็นเอฟเฟกต์ของม็อด Epic Fight Nightfall แต่ผมยังไม่เห็น id จริงจากเอกสาร/ซอร์ส จึงจับแบบกว้าง: MobEffect ที่ path มีคำว่า `stop` (namespace ใดก็ได้) หรืออยู่ในตระกูล epicfight/efn/nightfall และไม่ใช่ BENEFICIAL ถ้า Stop ไม่ใช่ MobEffect จะ **ไม่ถูกล้าง** ตอนติด Stop ผู้เล่นพิมพ์คำสั่งไม่ได้ และบนมือถือเปิด log ไม่สะดวก จึง **ไม่มีคำสั่งและไม่ต้องเปิด log** — ม็อดส่งข้อความ id ของเอฟเฟกต์ (ของม็อดอื่น) เข้าแชตให้เอง |
| เจาะ `pehkui:defense` (v1.1.0) | ❌ ยังไม่ได้ยืนยัน | อ่านซอร์ส Pehkui ไม่ได้ (GitHub บล็อกหน้าโฟลเดอร์) จึงเรียกผ่าน reflection ด้วยชื่อ API ที่ผมจำได้ (`ScaleTypes.DEFENSE`, `ScaleType#getScaleData`, `ScaleData#getScale/setScale`) ถ้าไม่ตรงจะปิดตัวเองโดยไม่แก้อะไร (เมื่อโจมตีครั้งแรกจะมีข้อความในแชต `[Divine Breaker] Pehkui bridge: ready` หรือ `disabled ...`) และยังไม่รู้ว่า Pehkui ลดดาเมจก่อนหรือหลัง event ที่เราเข้าไปแก้ |
| Build ด้วย Gradle / ForgeGradle | ❌ ยังไม่ได้ทำ | ต้อง Build ใน GitHub Actions หรือเครื่องที่มีเครือข่าย |
| ทดสอบในเกม (ทุกสกิล, Epic Fight, Pehkui) | ❌ ยังไม่ได้ทำ | ใช้ตารางในข้อ 7 |
| Push ขึ้น GitHub | ❌ ยังไม่ได้ทำ | ทำเองตามข้อ 4 |

## 3. Dependency และเวอร์ชัน

| รายการ | เวอร์ชัน | หมายเหตุ |
|--------|----------|----------|
| Minecraft | 1.20.1 | |
| Forge | 47.4.10 (ตอน compile) | ถ้า Gradle หาเวอร์ชันนี้ไม่เจอ ให้แก้ `forge_version` ใน `gradle.properties` เป็นรุ่น 47.x อื่น เช่น `47.3.0` |
| Java | 17 | |
| ForgeGradle | 6.0.x (`[6.0,6.2)`) | Gradle 8.1.1 |
| Origins Forge (รวม Apoli + Calio) | 1.10.0.x | จำเป็นตอนรัน; ใน `mods.toml` ตั้ง `mandatory=false` ไว้ก่อน เพราะยังไม่ได้ยืนยัน modId จากไฟล์ของ Origins Forge — ถ้ายืนยันว่าเป็น `origins` ค่อยเปลี่ยนเป็น `true` |
| Epic Fight | 20.14.17 | ไม่บังคับ (โค้ดไม่ได้ลิงก์ตอน compile) |
| Pehkui | รุ่น 1.20.1 Forge | ไม่บังคับ (โค้ดไม่ได้ลิงก์ตอน compile) |

โค้ด Java ใช้เฉพาะ Minecraft + Forge API → Build ไม่ต้องหา Maven ของ Origins / Epic Fight / Pehkui

## 4. วิธี Build

**ทางที่ 1 — GitHub Actions (เหมาะกับมือถือ)**
1. ในรีโป `phfhgudo-gif/1` **ลบไฟล์เก่า** (zip/jar ของโปรเจกต์ก่อนหน้า) ก่อน
2. อัปโหลด `divine-breaker-mod.zip` ไปที่ root ของรีโป
3. ถ้า workflow เดิมของคุณแปลง zip → jar ได้อยู่แล้ว ให้ใช้ตัวเดิม ถ้าไม่ได้ ให้คัดลอก `extras/build-divine-breaker.yml` ไปไว้ที่ `.github/workflows/build-divine-breaker.yml` (workflow นี้แตก zip → build → **ลบ jar เก่าในโฟลเดอร์ `jars/`** → ใส่ jar ใหม่ → commit)
4. แท็บ Actions → Run workflow → ดาวน์โหลด JAR จากโฟลเดอร์ `jars/` หรือ artifact `divinebreaker-jar`

**ทางที่ 2 — เครื่องคอมพิวเตอร์**
```
JDK 17 + Gradle 8.1.1
gradle build
# ได้ไฟล์ build/libs/divinebreaker-1.2.1.jar
```
(โปรเจกต์ไม่มี `gradle-wrapper.jar` เพราะสร้างโดยไม่มีเครือข่าย ถ้าต้องการให้รัน `gradle wrapper --gradle-version 8.1.1`)

ถ้า Build ล้ม: ส่งบรรทัดแรก ๆ ที่ขึ้นต้นด้วย `error:` หรือ `What went wrong` จาก log มาให้ผม

## 5. วิธีติดตั้ง
ใส่ `divinebreaker-1.2.1.jar` ลงโฟลเดอร์ `mods/` ของ instance Forge 1.20.1 ที่มี Origins Forge (+ Apoli/Calio), Epic Fight 20.14.17 และ Pehkui (สองตัวหลังไม่บังคับ)
ต้องลงทั้งฝั่ง client และ server (ม็อดเพิ่ม attribute ใน registry)

## 6. วิธีเลือก Origin และตั้งปุ่ม
- ผู้เล่นใหม่: เลือกจากหน้า Origin Selection ตอนเข้าเกม — Divine Breaker อยู่ในรายการของ layer `origins:origin`
- ผู้เล่นที่เลือก Origin ไปแล้ว (ต้องเป็น OP): `/origin set <ชื่อผู้เล่น> origins:origin divinebreaker:divine_breaker`
- ตั้งปุ่ม: Options → Controls → Key Binds → หมวดของ Origins (Primary Ability / Secondary Ability)
  Green Vitality ใช้ Primary, Purification ใช้ Secondary → **ไม่ชนกัน** (เปลี่ยนปุ่มได้ใน Controls)

## 7. วิธีทดสอบแต่ละสกิล (ผลจริง: ⬜ = ยังไม่ได้ทดสอบ)

**ตรวจโหลดเบื้องต้น**
- `/power list @s` ต้องเห็น 5 power ของ `divinebreaker:`
- `/attribute @s divinebreaker:armor_breaker get` → `1.0` (เช่นเดียวกับ `soul_walker`, `web_phantom`)
- ถ้าเปิด `logs/latest.log` ได้ ค้นคำว่า `divinebreaker`, `Couldn't parse`, `apoli` ต้องไม่มี error (บนมือถือที่เปิด log ไม่ได้: ดูว่า `/power list @s` ขึ้น power ครบ และคำสั่ง `/attribute` ข้างบนตอบ `1.0`)

**Green Vitality** ⬜ — `/damage @s 15` แล้วกด Primary: เลือดเพิ่มสูงสุด 50 แต่ไม่เกินเลือดสูงสุด, อนุภาคเขียวขึ้นรอบตัว, ใช้ซ้ำไม่ได้ 10 วินาที ถ้าเลือดเต็มแล้วกด: `/data get entity @s Health` ต้องไม่เกินค่าสูงสุด (ไม่มีการเพิ่ม Max Health ถาวร)

**Purification** ⬜ — `/effect give @s minecraft:poison 60 1`, `.../weakness 60 1`, `.../speed 60 1` แล้วกด Secondary: poison + weakness หาย, speed ยังอยู่ ทดสอบเพิ่มด้วย `slowness`, `wither`, `blindness`, `hunger`, `nausea`, `levitation`, `unluck`, `mining_fatigue`, `darkness`

**Soul Walker** ⬜ — ปู Soul Sand 10 บล็อก เดินเทียบกับพื้นหิน ต้องใกล้เคียงกัน; สลับเป็น `origins:empty` แล้ว Soul Sand ต้องช้าลงชัดเจน; Honey Block ต้องยังช้าเหมือนเดิม; Soul Soil ใน vanilla 1.20.1 ไม่ชะลออยู่แล้ว

**Web Phantom** ⬜ — เดิน/วิ่งผ่านทางเดินใยแมงมุม ต้องไม่ช้าลงและไม่หยุดกึก; มอนสเตอร์/ผู้เล่นอื่นยังติดใยตามปกติ; ตกลงใยแมงมุมยังไม่เจ็บเหมือน vanilla

**Stop Cleanser** ⬜ — ตอนเป็น Divine Breaker ให้ตัวที่ใช้ Stop โจมตีคุณ แล้วดูแชต: จะมีข้อความ `[Divine Breaker] BLOCKED: <id> [<ประเภท>]` (ถ้ากันได้) หรือ `NOT MATCHED ...: <id>` (ถ้าไม่ตรงกฎ) — ถ่ายภาพหน้าจอ/พิมพ์ข้อความนั้นส่งให้ผมเพื่อใส่ id ที่ตรงเป๊ะ ถ้าไม่มีข้อความขึ้นเลยและยังขยับไม่ได้ แปลว่า Stop ไม่ใช่ MobEffect → ต้องหา API ของม็อดนั้น

**Armor Breaker** (ข้อ 7.5 ของโจทย์) — เตรียมเป้า:
```
/summon zombie ~ ~ ~ {NoAI:1b,PersistenceRequired:1b,ArmorItems:[{id:"minecraft:netherite_boots",Count:1b},{id:"minecraft:netherite_leggings",Count:1b},{id:"minecraft:netherite_chestplate",Count:1b},{id:"minecraft:netherite_helmet",Count:1b}],ArmorDropChances:[0.0F,0.0F,0.0F,0.0F]}
/data get entity @e[type=zombie,limit=1,sort=nearest] Health
```
ตีด้วยดาบเพชรเต็มชาร์จ (ดาเมจ 7.0) นิ่งอยู่บนพื้น ไม่วิ่ง ไม่ crit

| # | กรณี | วิธี | ผลที่คาดหวัง | ผลจริง |
|---|------|------|--------------|--------|
| 1 | เป้าไม่มีเกราะ | ซอมบี้ไม่ใส่เกราะ | เลือดลด 7.0 ทั้งมี/ไม่มี Origin | ⬜ |
| 2 | เกราะเต็มชุด | ซอมบี้เกราะเพชร | ไม่มี Origin: น้อยกว่า 7 มาก • มี Origin: 7.0 | ⬜ |
| 3 | Toughness สูง | ซอมบี้เกราะ netherite (armor 20, toughness 12) | ไม่มี Origin ≈ 1.79 • มี Origin = 7.0 | ⬜ |
| 4 | Epic Fight Combat Mode | กด R (ค่าเริ่มต้นของ Epic Fight) สลับโหมด แล้วโจมตีเป้าเดียวกัน | ดาเมจเมื่อมี Origin มากกว่าตอนไม่มี Origin กับเป้าเกราะเต็ม ถ้า **เท่ากัน = ไม่ผ่าน** แปลว่า Epic Fight 20.14.17 ไม่ได้อ่านเกราะผ่าน attribute → ส่ง log/ผลมาให้ผมปรับ | ⬜ |
| 5 | Resistance | `/effect give @e[type=zombie,limit=1,sort=nearest] minecraft:resistance 60 1` | 7 × 0.6 = 4.2 (Resistance ยังทำงาน ไม่ถูกเจาะ) | ⬜ |
| 6 | เจาะ Pehkui defense (v1.1.0) | `/scale set pehkui:defense 0.5 @e[type=zombie,limit=1,sort=nearest]` (หลังโจมตีครั้งแรกต้องมีข้อความในแชต `Pehkui bridge: ready` ถ้าขึ้น `disabled` แปลว่าไม่มีผลและให้ส่งข้อความนั้นมาให้ผม) | มี Origin: ดาเมจเท่าตอนไม่ได้ตั้ง defense (7.0 กับซอมบี้ไม่มีเกราะ) • ไม่มี Origin: เหลือครึ่งหนึ่ง/ตามสูตร Pehkui • หลังตี `/scale get pehkui:defense <ซอมบี้>` ต้องกลับเป็น 0.5 | ⬜ |
| 7 | เทียบก่อน/หลังเปิด Origin | `/origin set @s origins:origin origins:empty` สลับกับ `divinebreaker:divine_breaker` | ดูผลข้อ 2–4 | ⬜ |
| 8 | ไม่มีดาเมจซ้ำ / ถอด modifier คืน | ตีครั้งเดียวต่อชาร์จเต็ม แล้ว `/attribute @e[type=zombie,limit=1,sort=nearest] minecraft:generic.armor get` | เลือดลดครั้งเดียว และเกราะกลับเป็น 20 | ⬜ |

สูตรของเกมที่ใช้คำนวณค่าคาดหวัง: `ดาเมจ × (1 − min(20, max(armor/5, armor − ดาเมจ/(2 + toughness/4)))/25)`
ตัวอย่างข้อ 3: `7 × (1 − 18.6/25) ≈ 1.79`

## 8. เหตุผลการออกแบบ
- **ตัวบ่งชี้เป็น attribute** (`divinebreaker:armor_breaker`, `soul_walker`, `web_phantom`): power JSON แบบ `apoli:attribute` ใส่ให้ผู้เล่น แล้วโค้ด Java อ่านค่านี้ → ไม่ต้องเรียก API ภายในของ Origins/Apoli (ซึ่งยังไม่ได้ตรวจกับซอร์สพอร์ต Forge) และเมื่อผู้เล่นเปลี่ยน Origin ตัวบ่งชี้ถูกถอดเอง
- **Armor Breaker** แก้ที่ attribute `ARMOR`/`ARMOR_TOUGHNESS` ของเป้าหมาย (modifier ชั่วคราว MULTIPLY_TOTAL −1.0) ระหว่าง `LivingHurtEvent` → `LivingDamageEvent` ไม่แก้ค่าดาเมจ ไม่เรียก `hurt()` ซ้ำ จึงไม่มีดาเมจซ้ำ; Resistance, Absorption, i-frames, โล่ และ Protection enchant ยังทำงาน; ถ้ามีม็อดอื่น cancel เหตุการณ์ จะถอด modifier คืนตอนจบ server tick
- **Purification** ใช้ `apoli:execute_command` สั่ง `/tag @s add divinebreaker_purify` (คำสั่งของ vanilla) แล้ว Java ตรวจแท็กนี้ท้าย tick ล้างเอฟเฟกต์ `MobEffectCategory.HARMFUL` และลบแท็ก (ครอบคลุมเอฟเฟกต์ของม็อดอื่นที่ประกาศตัวเองเป็น harmful) แทนการไล่ชื่อเอฟเฟกต์ vanilla — **ม็อดนี้ไม่มีคำสั่งของตัวเองให้พิมพ์**
- **Soul Walker / Web Phantom** ใช้ Forge event ไม่ใช้ Mixin เพื่อลดความเสี่ยงตอน Build (ไม่มีการตั้งค่า Mixin ที่ทดสอบไม่ได้) แลกกับความแม่นยำที่เป็น "การชดเชย" ไม่ใช่การแก้ที่ต้นทาง

## 9. ข้อจำกัดที่ทราบ
1. **Epic Fight stun / knockdown ไม่ถูกล้าง** — เป็นสถานะของระบบต่อสู้ ไม่ใช่ MobEffect และผมไม่พบ API สาธารณะสำหรับล้าง จึงไม่แตะตามข้อกำหนด (ห้ามแก้ NBT/สถานะภายในแบบสุ่ม) และยังไม่พบหลักฐานว่า Epic Fight 20.14.17 เพิ่ม MobEffect ด้านลบของตัวเอง
2. Armor Breaker นับเฉพาะการโจมตีที่ผู้เล่นเป็นผู้โจมตีโดยตรง (ระยะประชิด/อาวุธ รวมโหมด Epic Fight) — **ไม่รวมกระสุน ระเบิด thorns** และไม่เจาะ Protection enchant, Resistance, Absorption, โล่ หรือระบบป้องกันเฉพาะของบอส/ม็อดอื่น (v1.1.0: เจาะ `pehkui:defense` ได้ตามข้อจำกัดข้อ 6)
6. การเจาะ `pehkui:defense` ทำโดยแก้ค่า scale ชั่วคราวแล้วคืน → ทุกครั้งที่โจมตีเป้าที่มี defense ≠ 1 จะมีการ sync scale ไป client 2 ครั้ง; ถ้าเป้ากำลังเปลี่ยนขนาด (interpolate) อยู่พอดี ค่าอาจกระตุก; และถ้า Pehkui ลดดาเมจก่อนที่เราเข้าไปแก้ได้ (โดยเฉพาะทาง Epic Fight) จะไม่เห็นผล — ต้องทดสอบจริง
7. Stop Cleanser ล้างได้เฉพาะ MobEffect เท่านั้น
3. Soul Walker เป็นการชดเชยฝั่ง client (หารด้วย speed factor ของบล็อกที่ชะลอ เฉพาะบล็อกใน tag `minecraft:soul_speed_blocks`) ไม่ทำงานถ้าผู้เล่นมี Soul Speed enchant (เกมจัดการเอง) และไม่ยุ่งกับ Honey Block
4. Web Phantom ไม่แตะ sweet berry bush / powder snow: ถ้าตัวผู้เล่นทับบล็อกเหล่านั้นพร้อมใยแมงมุม จะไม่เขียนทับอะไร
5. (v1.2.0) ม็อดนี้ไม่มีคำสั่งของตัวเองแล้ว; Purification ใช้แท็ก `divinebreaker_purify` ซึ่งเพิ่มได้ด้วย `/tag` ต้องสิทธิ์ OP เท่านั้น

## 10. ปรับแต่ง
- จำนวนฮีล / คูลดาวน์: `data/divinebreaker/powers/green_vitality.json` (`amount`, `cooldown`)
- คูลดาวน์ Purification: `data/divinebreaker/powers/purification.json`
- สัดส่วนเจาะเกราะ: `data/divinebreaker/powers/armor_breaker.json` ช่อง `value` (1.0 = 100%, 0.5 = 50%)

## 11. แก้ปัญหาเบื้องต้น
| อาการ | ตรวจอะไร |
|-------|----------|
| ไม่เห็น Origin ในหน้าเลือก | ถ้าเปิด log ได้ ค้น `divinebreaker` / `Couldn't parse` / `apoli` (ถ้าเปิดไม่ได้ ให้ส่งข้อความ error ที่หน้าจอแสดงมาให้ผม); ตรวจว่า mod โหลดแล้ว (หน้า Mods); ผู้เล่นที่เลือกไปแล้วต้องใช้ `/origin set` |
| เกมไม่ยอมเริ่ม | อ่านข้อความ "Mod divinebreaker requires ..." ใน log/หน้าจอ แล้วส่งมาให้ผม |
| กดปุ่มสกิลแล้วไม่เกิดอะไร | ตั้งปุ่มใน Controls; ดูว่าปุ่มชนกับม็อดอื่นไหม; ดู cooldown bar |
| Purification ไม่ล้าง | OP ลองรัน `/tag @s add divinebreaker_purify`: ถ้าเอฟเฟกต์ด้านลบหายภายใน 1 tick ปัญหาอยู่ที่การเรียกจาก power (`apoli:execute_command`); ถ้าไม่หาย แปลว่าม็อดไม่ได้โหลด หรือเอฟเฟกต์นั้นไม่ใช่ประเภท HARMFUL |
| Soul Sand ยังช้าอยู่ | `/attribute @s divinebreaker:soul_walker get` ต้องเป็น 1.0; ตรวจว่าไม่ได้ใส่ Soul Speed; ทดสอบฝั่ง client (ม็อดต้องอยู่ในเครื่องผู้เล่น) |
| Armor Breaker ไม่เห็นผล | ทำข้อ 7 ตาราง 1–3 ก่อน (vanilla) แล้วค่อยข้อ 4 (Epic Fight) และแจ้งผลว่าข้อไหนไม่ผ่าน |
| Build ล้มเรื่อง Forge/Gradle | ลองเปลี่ยน `forge_version` ใน `gradle.properties`; ส่ง log มาให้ผม |

## 12. โครงสร้างไฟล์
```
build.gradle, settings.gradle, gradle.properties, .gitignore, README.md
extras/build-divine-breaker.yml          (workflow ตัวเลือก)
src/main/java/dev/divinebreaker/
    DivineBreaker.java                   (คลาสหลัก, ลงทะเบียน event)
    ModAttributes.java                   (attribute ตัวบ่งชี้ 3 ตัว)
    ArmorBreakerHandler.java             (เจาะเกราะ)
    WebPhantomHandler.java               (ใยแมงมุม)
    PurifyHandler.java                   (Purification: ตรวจแท็กแล้วล้างเอฟเฟกต์ HARMFUL)
    StopCleanserHandler.java             (เคลียร์เอฟเฟกต์ Stop ของ Epic Fight)
    PehkuiBridge.java                    (reflection ไปยัง pehkui:defense)
    PehkuiPierceHandler.java             (เจาะ defense ของ Pehkui)
    client/SoulWalkerClient.java         (Soul Sand ฝั่ง client)
src/main/resources/
    META-INF/mods.toml, pack.mcmeta
    assets/divinebreaker/lang/en_us.json, th_th.json
    data/divinebreaker/origins/divine_breaker.json
    data/divinebreaker/powers/*.json     (5 power)
    data/origins/origin_layers/origin.json
```

## 13. ประวัติการแก้ไข
- **1.2.1** — Stop Cleanser ส่งข้อความ id ของเอฟเฟกต์เข้าแชต (แทนการให้เปิด `logs/latest.log` ซึ่งบนมือถือเปิดไม่ได้); แจ้งสถานะ Pehkui bridge ทางแชตตอนโจมตีครั้งแรก; ตั้งค่า `CHAT_FEEDBACK` ใน `StopCleanserHandler.java` เป็น `false` เมื่อไม่ต้องการข้อความนี้แล้ว
- **1.2.0** — ลบคำสั่ง `/divinebreaker` ทั้งหมด (purify / effects / pehkui) เพราะตอนติด Stop ผู้เล่นพิมพ์คำสั่งไม่ได้: Purification เปลี่ยนไปใช้แท็ก vanilla + Java; Stop Cleanser จับ `stop` ทุก namespace และเขียน id เอฟเฟกต์ลง log แทนคำสั่ง
- **1.1.1** — Stop Cleanser รองรับเอฟเฟกต์ Stop ของม็อด Epic Fight Nightfall (จับ path `stop` ทุก namespace + ตระกูล epicfight/efn/nightfall)
- **1.1.0** — เพิ่ม passive Stop Cleanser (power `divinebreaker:stop_cleanser`, attribute `divinebreaker:stop_cleanser`); Armor Breaker เจาะ `pehkui:defense` ด้วย (PehkuiBridge + PehkuiPierceHandler); เพิ่มคำสั่งตรวจ `/divinebreaker effects` และ `/divinebreaker pehkui`; ใช้ `jars/divinebreaker-1.1.0.jar`
- 1.0.0 — เวอร์ชันแรก (5 สกิล)
